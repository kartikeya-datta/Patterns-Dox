package linkedlist;

public class Node {
	
	Node next;
	int color;
	
	public Node(String colors) {
		color=colors;
	}
	
	
}

/**
 * 
 */
/**
 * 
 */
module LinkedListInClass {
}
package demo;

public class Sample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10,b=14;
		System.out.print(a+b);
	}

}


package demo;
import java.util.*;
/**
 * @author S566425 Sri Vasavi Peravarapu
 */
public class PatternsDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("10");

	}

}

package linkedlist;

public class Node {
	
	Node next;
	Node prev;
	String carmodel;
	
	public Node(String carmodels) {
		carmodel=carmodels;
	}

}
